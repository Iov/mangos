-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r19 r20 bit;
 
-- sql content between the lines --------------  start 

-- small walk around for now
-- -----------------------------------------------------------------------------------------
/* Scourge Gryphon */ -- to correct rsa typo & Correct gryphon
UPDATE creature_template SET
    spell1 = 57403,
    spell2 = 0,
    spell3 = 0,
    spell4 = 0,
    spell5 = 0,
    spell6 = 0,
    vehicle_id = 25
WHERE entry IN (28864);

DELETE FROM `creature_template_addon` WHERE (`entry`=28864);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `b2_0_sheath`, `b2_1_pvp_state`, `emote`, `moveflags`, `auras`) VALUES (28864, 0, 0, 0, 0, 0, 0, 61453);
-- -----------------------------------------------------------------------------------------

-- sql content between the lines -------------- end
REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r20');
UPDATE db_version SET `cache_id`= '20';
UPDATE db_version SET `version`= '_Infinity_YTDB_594_V1_r20';