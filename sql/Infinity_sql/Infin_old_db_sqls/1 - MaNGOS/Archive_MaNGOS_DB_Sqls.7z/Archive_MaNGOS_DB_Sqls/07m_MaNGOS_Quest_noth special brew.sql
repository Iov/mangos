-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r06 r07 bit;

-- sql content between the lines --------------  start

UPDATE `quest_template` SET `SpecialFlags` = 0 WHERE `entry` = 12717;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r07');
UPDATE db_version SET `cache_id`= '07';
UPDATE db_version SET `version`= '_Infinity_YTDB_591_V1_r07';