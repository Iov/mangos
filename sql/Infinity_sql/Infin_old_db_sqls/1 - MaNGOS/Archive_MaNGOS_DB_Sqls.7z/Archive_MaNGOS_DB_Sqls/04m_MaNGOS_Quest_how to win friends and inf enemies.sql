-- FallenAngelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r03 r04 bit;

-- sql content between the lines --------------  start

-- How To Win Friends And Influence Enemies
UPDATE `creature_template` SET `ScriptName`='npc_crusade_persuaded' WHERE `entry` IN (28939,28940,28610);

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r04');

UPDATE db_version SET `cache_id`= '04';
UPDATE db_version SET `version`= '_Infinity_YTDB_590_V1_r04';