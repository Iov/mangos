-- ancient
ALTER TABLE db_version_infinity_update CHANGE COLUMN r22 r23 bit;
 
-- sql content between the lines --------------  start 

DELETE FROM achievement_criteria_requirement WHERE criteria_id IN (6651, 6652, 6653, 6654, 6655, 6656, 6657, 12398);
INSERT INTO achievement_criteria_requirement (criteria_id, type, value1, value2) VALUES
('6651','16','201','0'),
('6652','16','201','0'),
('6653','16','201','0'),
('6654','16','201','0'),
('6655','16','201','0'),
('6656','16','201','0'),
('6657','16','201','0'),
('12398','16','201','0');

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r23');
UPDATE db_version SET `cache_id`= '23';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r23';