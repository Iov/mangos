-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r08 r09 bit;

-- sql content between the lines --------------  start

-- an end to all things
UPDATE `quest_template` SET `ReqItemId1` = 39700, `ReqItemCount1` = 1 WHERE `entry` = 12779; -- make horn of frost a required item in quest this is so players arent left with the item

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r09');
UPDATE db_version SET `cache_id`= '09';
UPDATE db_version SET `version`= '_Infinity_YTDB_591_V1_r09';