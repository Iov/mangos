-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r23 r24 bit;
 
-- sql content between the lines --------------  start 

UPDATE npc_trainer SET reqskillvalue = 315 WHERE spell = 56991;
UPDATE npc_trainer SET reqskillvalue = 375 WHERE spell = 62162;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r24');
UPDATE db_version SET `cache_id`= '24';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r24';