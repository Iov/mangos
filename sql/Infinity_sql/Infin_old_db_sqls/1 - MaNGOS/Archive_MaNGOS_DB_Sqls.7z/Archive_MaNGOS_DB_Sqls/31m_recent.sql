-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r30 r31 bit;
 
-- sql content between the lines --------------  start 
-- Instance Utgarde Pinnacle
UPDATE `creature_template` SET `ScriptName` = 'npc_spectator' WHERE `entry` = '26667';
UPDATE `creature_template` SET `AIName` = 'NUllAI' WHERE `entry` = '27327';

-- Instance Utgarde Pinnacle
UPDATE `gameobject_template` SET `ScriptName` = 'go_stasis_generator' WHERE `entry` = '188593';
UPDATE `gameobject_template` SET `ScriptName` = 'go_skaldi_harpoonlauncher' WHERE `entry` IN ('192175','192176','192177');

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r31');
UPDATE db_version SET `cache_id`= '31';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r31';