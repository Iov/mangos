-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r32 r33 bit;

-- sql start here ------------------------------ start

UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 16684;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 13283;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 5167;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 4163;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 4583;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 5165;

UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 918;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 16684;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 3328;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 13283;


-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r33');
UPDATE db_version SET `cache_id`= '33';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r33';