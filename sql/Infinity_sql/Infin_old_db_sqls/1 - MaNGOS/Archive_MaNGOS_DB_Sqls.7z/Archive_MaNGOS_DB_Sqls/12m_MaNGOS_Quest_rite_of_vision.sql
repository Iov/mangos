-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r11 r12 bit;

-- sql content between the lines --------------  start

-- Rite of Vision

UPDATE `creature_template` SET `MovementType`='0', `flags_extra`='64', `speed_walk`='1' WHERE (`entry`='2983');
UPDATE `quest_template` SET `SpecialFlags`='2' WHERE (`entry`='772');
UPDATE `creature_template` SET `ScriptName`='npc_plains_vision' WHERE (`entry`='2983');

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r12');
UPDATE db_version SET `cache_id`= '12';
UPDATE db_version SET `version`= '_Infinity_YTDB_591_V1_r12';