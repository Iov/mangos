-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r09 r10 bit;

-- sql content between the lines --------------  start

-- scarlet monastry headless horseman
UPDATE creature_template SET ScriptName = 'boss_headless_horseman' WHERE entry = 23682;
UPDATE creature_template SET ScriptName = 'npc_horsemans_head' WHERE entry = 23775;

-- Head of the Horseman
UPDATE `creature_template` SET 
`minlevel`='70',
`maxlevel`='70',
`minhealth`='63000',
`maxhealth`='63000',
`armor`='1000',
`mindmg`='1200',
`maxdmg`='1600',
`faction_A`='14',
`faction_H`='14',
`mechanic_immune_mask`='2048' 
WHERE `entry`='23775';

UPDATE creature_template SET 
`minlevel` = 70,
`maxlevel` = 70,
`minhealth` = 4541,
`maxhealth` = 4541,
`armor` = 6792,
`mindmg` = 651,
`maxdmg` = 834,
`baseattacktime` = 2000,
`mechanic_immune_mask` = '8388624',
`faction_A` = 14,
`faction_H` = 14
WHERE entry IN (23545,23694);

UPDATE creature_template SET ScriptName = 'mob_pulsing_pumpkin' WHERE entry = 23694;
-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r10');
UPDATE db_version SET `cache_id`= '10';
UPDATE db_version SET `version`= '_Infinity_YTDB_591_V1_r10';