-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r12 r13 bit;

-- sql content between the lines --------------  start

-- army of dead ghould 
UPDATE `creature_template` SET `ScriptName` = 'mob_risen_ghoul' WHERE `entry` = 24207;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r13');
UPDATE db_version SET `cache_id`= '13';
UPDATE db_version SET `version`= '_Infinity_YTDB_591_V1_r13';