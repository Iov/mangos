-- INFERNA TEAM
ALTER TABLE db_version_infinity_update CHANGE COLUMN r18 r19 bit;

-- start here

-- Update Required Zone for Achievement Spring Fling 2419

UPDATE `achievement_criteria_requirement` SET `value1`='186' WHERE (`criteria_id`='9199') AND (`type`='6');

-- Experience Eliminator

UPDATE `creature_template` SET `ScriptName` = "npc_experience_eliminator" WHERE `entry` IN (35365,35364);

-- Noblegarden Spring Fling

UPDATE `creature_template` SET `ScriptName`='pet_spring_rabbit' WHERE `entry`='32791';

-- end here

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r19');
UPDATE db_version SET `cache_id`= '19';
UPDATE db_version SET `version`= '_Infinity_YTDB_594_V1_r19';