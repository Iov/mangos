-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r28 r29 bit;
 
-- sql content between the lines --------------  start 

UPDATE `creature_template` SET `difficulty_entry_1` = 33942 WHERE `entry` = 33809;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 33942;

UPDATE `creature_template` SET `difficulty_entry_1` = 33908 WHERE `entry` = 33768;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 33908;

UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 34189;
UPDATE `creature_template` SET `difficulty_entry_1` = 34189 WHERE `entry` = 34188;

UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 33353;
UPDATE `creature_template` SET `difficulty_entry_1` = 33353 WHERE `entry` = 32938;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r29');
UPDATE db_version SET `cache_id`= '29';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r29';