-- FallenAngelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r04 r05 bit;

-- sql content between the lines --------------  start

-- Bloody Breakout
DELETE FROM `creature` WHERE `id`=28912;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(116831, 28912, 609, 1, 4, 0, 0, 1656.03, -6038.49, 128.644, 2.96436, 25, 0, 0, 392100, 0, 0, 0);
UPDATE `creature_template` SET `mechanic_immune_mask` = 2146435071 WHERE `entry` = 28912; -- ( suppose to make deathweaver immune to turn but doesnt but it is the correct mask )

UPDATE `creature_template` SET `ScriptName`='mob_high_inquisitor_valroth',minmana=6489,maxmana=6489,unit_flags=32768,ainame="" WHERE `entry`='29001';

DELETE FROM `creature` WHERE `id`=29007;
UPDATE `creature_template` SET `AIName`='EventAI',minmana=1020,maxmana=1058,unit_flags=32768 WHERE (`entry`='29007');

UPDATE `creature_template` SET `AIName` = 'EventAI', `ScriptName` = '' WHERE `entry` = '29007';
DELETE FROM `creature_ai_scripts` WHERE (`id`='2900702');
INSERT INTO `creature_ai_scripts` VALUES ('2900702', '29007', '0', '0', '100', '1', '1000', '4000', '1000', '4000', '11', '15498', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Crimson Acolyte - Holy Smite');

UPDATE `creature_template` SET `AIName` = 'EventAI', `ScriptName` = '' WHERE `entry` = '29007';
DELETE FROM `creature_ai_scripts` WHERE (`id`='2900701');
INSERT INTO `creature_ai_scripts` VALUES ('2900701', '29007', '4', '0', '100', '0', '0', '0', '0', '0', '11', '15498', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Crimson Acolyte on aggro cast smite');


UPDATE `creature_template` SET `AIName` = 'EventAI', `ScriptName` = '' WHERE `entry` = '29007';
DELETE FROM `creature_ai_scripts` WHERE (`id`='2900703');
INSERT INTO `creature_ai_scripts` VALUES ('2900703', '29007', '11', '0', '100', '1', '0', '0', '0', '0', '11', '34809', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', 'Crimson Acolyte - Cast Holy Fury on Spawn');

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r05');

UPDATE db_version SET `cache_id`= '05';
UPDATE db_version SET `version`= '_Infinity_YTDB_590_V1_r05';