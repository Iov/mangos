-- FallenAngelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r01 r02 bit;

-- sql content between the lines --------------  start

-- Quest gift of the harvester
UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28822;
UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28819;
UPDATE `creature_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 28891;

UPDATE `item_template` SET `ScriptName` = 'mob_scarlet_miner' WHERE `entry` = 39253;

-- should in theory take away the gift of the harvest item out of player inventory upon quest complete // kinda untested didnt notice bug til a few quest  after i did this quest
UPDATE `quest_template` SET `ReqItemId1` = 39253, `ReqItemCount1` = 1 WHERE `entry` = 12698;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r02');

UPDATE db_version SET `cache_id`= '02';
UPDATE db_version SET `version`= '_Infinity_YTDB_590_V1_r02';