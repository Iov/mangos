-- fallenangelx
ALTER TABLE db_version_infinity_update CHANGE COLUMN r15 r16 bit;

-- start here

DELETE FROM `spell_proc_event` WHERE `entry` IN (51682); 
INSERT INTO `spell_proc_event` VALUES 
(51682, 0x00,  8, 0x10014000, 0x10014000, 0x10014000, 0x00080000, 0x00080000, 0x00080000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0.000000, 0.000000,  0); 

-- end here

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r16');
UPDATE db_version SET `cache_id`= '16';
UPDATE db_version SET `version`= '_Infinity_YTDB_593_V1_r16';
