-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r31 r32 bit;

-- sql start here ------------------------------ start

UPDATE `creature_template` SET `ScriptName` = 'mob_spirit_fount' WHERE `entry` = '27339';
 

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r32');
UPDATE db_version SET `cache_id`= '32';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r32';