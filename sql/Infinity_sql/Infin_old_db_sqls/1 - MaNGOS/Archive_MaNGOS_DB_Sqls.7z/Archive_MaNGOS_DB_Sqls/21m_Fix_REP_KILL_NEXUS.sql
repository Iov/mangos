-- fallenangelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r20 r21 bit;
 
-- sql content between the lines --------------  start 

-- fixed commander korlug faction on kill according to wowhead.com
UPDATE `creature_onkill_reputation` SET `RewOnKillRepFaction1` = 1068, `RewOnKillRepFaction2` = 1091, `RewOnKillRepValue1` = 63, `RewOnKillRepValue2` = 163 WHERE `creature_id` = 26798;

-- 


-- sql content between the lines -------------- end
REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r21');
UPDATE db_version SET `cache_id`= '21';
UPDATE db_version SET `version`= '_Infinity_YTDB_594_V1_r21';