-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r24 r25 bit;
 
-- sql content between the lines --------------  start 
--
DELETE FROM `command` WHERE `name` = 'bot'; 
INSERT INTO `command` (`name`,`security`,`help`) VALUES 
('bot',0,'Syntax:\r.bot add BOTNAME (add character to world)\r.bot remove BOTNAME (remove character from world)\r.bot co|combatorder BOTNAME COMBATORDER [TARGET]');
--
DELETE FROM `gossip_menu_option` WHERE `menu_id` = 0 AND `id` = 16 AND `option_id` = 18;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r25');
UPDATE db_version SET `cache_id`= '25';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r25';