-- FallenAngelX
ALTER TABLE db_version_infinity_update CHANGE COLUMN r00 r01 bit;

-- sql content between the lines --------------  start

-- Jack Adams dancing on the table
DELETE FROM creature_addon WHERE guid = 115895;
INSERT INTO creature_addon (guid,mount,bytes1,b2_0_sheath,b2_1_pvp_state,emote) VALUES
(115895,0,0,0,0,10);

UPDATE creature_template SET ScriptName = 'npc_olga', AIName = '' WHERE entry = 24639;
UPDATE creature_template SET ScriptName = 'npc_jack_adams', AIName = '' WHERE entry = 24788;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r01');

UPDATE db_version SET `cache_id`= '01';
UPDATE db_version SET `version`= '_Infinity_YTDB_590_V1_r01';