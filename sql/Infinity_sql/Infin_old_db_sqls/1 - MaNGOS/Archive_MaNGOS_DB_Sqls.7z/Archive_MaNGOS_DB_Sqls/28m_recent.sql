-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r27 r28 bit;
 
-- sql content between the lines --------------  start 

UPDATE `creature_template` SET `ScriptName`='npc_captured_rabid_thistle_bear' WHERE `entry`='11836';
UPDATE `creature_template` SET `ScriptName`='npc_rabid_thistle_bear' WHERE `entry`='2164';

UPDATE `quest_template` SET `ReqSpellCast1`='0' WHERE (`entry`='2118');


-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r28');
UPDATE db_version SET `cache_id`= '28';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r28';