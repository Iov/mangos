-- fallenangelx
ALTER TABLE db_version_infinity_update CHANGE COLUMN r17 r18 bit;

-- start here

-- fix a graphic and minor pet bug for the dragonhawks around silvermoon
UPDATE `creature_template` SET `InhabitType` = 3 WHERE `entry` = 15649;

-- end here

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r18');
UPDATE db_version SET `cache_id`= '18';
UPDATE db_version SET `version`= '_Infinity_YTDB_594_V1_r18';