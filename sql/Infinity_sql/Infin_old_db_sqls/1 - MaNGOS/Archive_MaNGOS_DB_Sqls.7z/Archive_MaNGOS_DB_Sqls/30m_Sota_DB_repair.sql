-- games
ALTER TABLE db_version_infinity_update CHANGE COLUMN r29 r30 bit;
 
-- sql content between the lines --------------  start 

UPDATE `creature_template` SET `difficulty_entry_1` = 32796 WHERE `entry` = 28781;
UPDATE `creature_template` SET `ScriptName` = '' WHERE `entry` = 32796;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r30');
UPDATE db_version SET `cache_id`= '30';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r30';