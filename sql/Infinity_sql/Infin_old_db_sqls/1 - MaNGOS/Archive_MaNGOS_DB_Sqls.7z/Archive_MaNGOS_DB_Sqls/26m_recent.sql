-- ancient
ALTER TABLE db_version_infinity_update CHANGE COLUMN r25 r26 bit;
 
-- sql content between the lines --------------  start 
-- Boss Lethon

UPDATE `creature_template` SET `ScriptName`='boss_lethon' WHERE `entry`=14888;

-- Orphans

UPDATE `creature_template` SET `ScriptName`='pet_orphan' WHERE `entry`='33533';
UPDATE `creature_template` SET `ScriptName`='pet_orphan' WHERE `entry`='33532';

-- Kirgaraak

UPDATE `creature_template` SET `ScriptName`='npc_kirgaraak' WHERE `entry`='29352';

-- Update Required Zone for Achievement Spring Fling 2419

UPDATE `achievement_criteria_requirement` SET `value1`='186' WHERE (`criteria_id`='9199') AND (`type`='6');
DELETE FROM `achievement_criteria_requirement` WHERE `criteria_id` IN ('9121','9199','9200','9201','9202','9203','9204','9205') AND `type` != '6';

UPDATE `creature_template` SET `ScriptName`= 'npc_brunnhildar_prisoner' WHERE `entry` = '29639';

UPDATE `creature_template` SET `ScriptName` = 'npc_freed_protodrake', `flags_extra`='4096' WHERE `entry` = '29709';
UPDATE creature_template SET spell1 = 54459, spell2 = 54458, spell3 = 54460 WHERE entry = 29918;

-- sql content between the lines -------------- end

REPLACE INTO `db_version_infinity_update` (`version`) VALUES ('r26');
UPDATE db_version SET `cache_id`= '26';
UPDATE db_version SET `version`= '_Infinity_YTDB_595_V1_r26';